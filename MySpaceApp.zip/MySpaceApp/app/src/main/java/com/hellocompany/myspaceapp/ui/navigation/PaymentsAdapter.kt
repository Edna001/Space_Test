package com.hellocompany.myspaceapp.ui.navigation

class PaymentsAdapter: {
}