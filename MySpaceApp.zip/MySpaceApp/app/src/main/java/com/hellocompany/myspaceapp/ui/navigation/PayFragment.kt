package com.hellocompany.myspaceapp.ui.navigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.hellocompany.myspaceapp.R
import kotlinx.android.synthetic.main.fragment_pay.*

class PayFragment : Fragment(R.layout.fragment_pay) {

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        back_button.setOnClickListener { view ->
            view.findNavController().popBackStack()
        }
    }
}
