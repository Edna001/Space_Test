package com.hellocompany.myspaceapp.ui.navigation

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.hellocompany.myspaceapp.R
import kotlinx.android.synthetic.main.fragment_payments.*

class PaymentsFragment : Fragment(R.layout.fragment_payments) {

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        next_button.setOnClickListener { view ->
            view.findNavController().navigate(R.id.action_paymentsFragment_to_payFragment)
        }
    }
}
